"use client"

import { useState } from "react"
import { UrlShortenerForm } from "@/components/url-shortener-form"
import { UrlList } from "@/components/url-list"
import { Analytics } from "@/components/analytics"
import { Header } from "@/components/header"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export interface ShortenedUrl {
  id: string
  originalUrl: string
  shortUrl: string
  shortCode: string
  clicks: number
  createdAt: Date
}

export default function Home() {
  const [urls, setUrls] = useState<ShortenedUrl[]>([])

  const addUrl = (url: ShortenedUrl) => {
    setUrls((prev) => [url, ...prev])
  }

  const incrementClicks = (id: string) => {
    setUrls((prev) => prev.map((url) => (url.id === id ? { ...url, clicks: url.clicks + 1 } : url)))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Hero Section */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900">Shorten Your URLs</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Transform long, complex URLs into short, shareable links. Track clicks and manage your links with ease.
            </p>
          </div>

          {/* URL Shortener Form */}
          <UrlShortenerForm onUrlShortened={addUrl} />

          {/* Tabs for URLs and Analytics */}
          <Tabs defaultValue="urls" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="urls">Your Links ({urls.length})</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="urls" className="space-y-4">
              <UrlList urls={urls} onUrlClick={incrementClicks} />
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <Analytics urls={urls} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
