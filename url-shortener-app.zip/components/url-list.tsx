"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Copy, ExternalLink, Eye, Calendar } from "lucide-react"
import type { ShortenedUrl } from "@/app/page"
import { formatDate } from "@/lib/utils"

interface UrlListProps {
  urls: ShortenedUrl[]
  onUrlClick: (id: string) => void
}

export function UrlList({ urls, onUrlClick }: UrlListProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null)

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), 2000)
    } catch (error) {
      console.error("Failed to copy:", error)
    }
  }

  const handleUrlClick = (url: ShortenedUrl) => {
    onUrlClick(url.id)
    window.open(url.originalUrl, "_blank")
  }

  if (urls.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <div className="text-gray-500">
            <ExternalLink className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No shortened URLs yet</p>
            <p className="text-sm">Create your first short link above!</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ExternalLink className="h-5 w-5" />
            Your Shortened URLs
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {urls.map((url) => (
            <div key={url.id} className="border rounded-lg p-4 space-y-3 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <button
                      onClick={() => handleUrlClick(url)}
                      className="text-blue-600 hover:text-blue-800 font-medium text-lg truncate"
                    >
                      {url.shortUrl}
                    </button>
                    <Badge variant="secondary" className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      {url.clicks}
                    </Badge>
                  </div>

                  <p className="text-sm text-gray-600 truncate mb-2">{url.originalUrl}</p>

                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDate(url.createdAt)}
                    </span>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(url.shortUrl, url.id)}
                  className="shrink-0"
                >
                  <Copy className="h-4 w-4 mr-1" />
                  {copiedId === url.id ? "Copied!" : "Copy"}
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
