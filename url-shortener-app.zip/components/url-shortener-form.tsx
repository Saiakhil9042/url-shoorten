"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Loader2, Link } from "lucide-react"
import type { ShortenedUrl } from "@/app/page"
import { generateShortCode, isValidUrl } from "@/lib/utils"

interface UrlShortenerFormProps {
  onUrlShortened: (url: ShortenedUrl) => void
}

export function UrlShortenerForm({ onUrlShortened }: UrlShortenerFormProps) {
  const [url, setUrl] = useState("")
  const [customAlias, setCustomAlias] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!url.trim()) {
      setError("Please enter a URL")
      return
    }

    if (!isValidUrl(url)) {
      setError("Please enter a valid URL")
      return
    }

    setIsLoading(true)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const shortCode = customAlias.trim() || generateShortCode()
      const shortUrl = `https://linkshort.ly/${shortCode}`

      const newUrl: ShortenedUrl = {
        id: Date.now().toString(),
        originalUrl: url,
        shortUrl,
        shortCode,
        clicks: 0,
        createdAt: new Date(),
      }

      onUrlShortened(newUrl)
      setUrl("")
      setCustomAlias("")
    } catch (error) {
      setError("Failed to shorten URL. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Link className="h-5 w-5" />
          Shorten Your URL
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="url">Enter your long URL</Label>
            <Input
              id="url"
              type="url"
              placeholder="https://example.com/very-long-url-that-needs-shortening"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="text-base"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="alias">Custom alias (optional)</Label>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500">linkshort.ly/</span>
              <Input
                id="alias"
                placeholder="my-custom-link"
                value={customAlias}
                onChange={(e) => setCustomAlias(e.target.value)}
                className="flex-1"
              />
            </div>
          </div>

          {error && <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</div>}

          <Button type="submit" className="w-full" disabled={isLoading} size="lg">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Shortening...
              </>
            ) : (
              "Shorten URL"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
